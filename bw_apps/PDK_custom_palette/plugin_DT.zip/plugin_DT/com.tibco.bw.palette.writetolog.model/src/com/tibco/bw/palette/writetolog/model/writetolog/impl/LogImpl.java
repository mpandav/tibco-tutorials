/**
 */
package com.tibco.bw.palette.writetolog.model.writetolog.impl;

import com.tibco.bw.palette.writetolog.model.writetolog.Log;
import com.tibco.bw.palette.writetolog.model.writetolog.WritetologPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Log</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.tibco.bw.palette.writetolog.model.writetolog.impl.LogImpl#getWriteToLog <em>Write To Log</em>}</li>
 * </ul>
 *
 * @generated
 */
public class LogImpl extends EObjectImpl implements Log {
	/**
	 * The default value of the '{@link #getWriteToLog() <em>Write To Log</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWriteToLog()
	 * @generated
	 * @ordered
	 */
	protected static final String WRITE_TO_LOG_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getWriteToLog() <em>Write To Log</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWriteToLog()
	 * @generated
	 * @ordered
	 */
	protected String writeToLog = WRITE_TO_LOG_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LogImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WritetologPackage.Literals.LOG;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getWriteToLog() {
		return writeToLog;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setWriteToLog(String newWriteToLog) {
		String oldWriteToLog = writeToLog;
		writeToLog = newWriteToLog;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WritetologPackage.LOG__WRITE_TO_LOG, oldWriteToLog, writeToLog));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case WritetologPackage.LOG__WRITE_TO_LOG:
				return getWriteToLog();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case WritetologPackage.LOG__WRITE_TO_LOG:
				setWriteToLog((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case WritetologPackage.LOG__WRITE_TO_LOG:
				setWriteToLog(WRITE_TO_LOG_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case WritetologPackage.LOG__WRITE_TO_LOG:
				return WRITE_TO_LOG_EDEFAULT == null ? writeToLog != null : !WRITE_TO_LOG_EDEFAULT.equals(writeToLog);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (WriteToLog: ");
		result.append(writeToLog);
		result.append(')');
		return result.toString();
	}

} //LogImpl
