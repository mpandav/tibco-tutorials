/**
 */
package com.tibco.bw.palette.writetolog.model.writetolog;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Log</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.tibco.bw.palette.writetolog.model.writetolog.Log#getWriteToLog <em>Write To Log</em>}</li>
 * </ul>
 *
 * @see com.tibco.bw.palette.writetolog.model.writetolog.WritetologPackage#getLog()
 * @model annotation="dkactivityconfig activitytype='Asynchronous' schemaType='XSD Editor' schemaFile='LogSchema.xsd' inputelementname='LogInput' outputelementname='' faultelementname='' helpdocuuid='f29ce2c5-fbd3-4e8e-a04c-7fef8672af4c'"
 * @generated
 */
public interface Log extends EObject {
	/**
	 * Returns the value of the '<em><b>Write To Log</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Write To Log</em>' attribute.
	 * @see #setWriteToLog(String)
	 * @see com.tibco.bw.palette.writetolog.model.writetolog.WritetologPackage#getLog_WriteToLog()
	 * @model annotation="dkcontrolconfig sectionName='General' isRequired='true' label='Label' isModelProperty='false' control='TextBox' value='' tooltip='Tooltip'"
	 * @generated
	 */
	String getWriteToLog();

	/**
	 * Sets the value of the '{@link com.tibco.bw.palette.writetolog.model.writetolog.Log#getWriteToLog <em>Write To Log</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Write To Log</em>' attribute.
	 * @see #getWriteToLog()
	 * @generated
	 */
	void setWriteToLog(String value);

} // Log
