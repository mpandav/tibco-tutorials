/**
 */
package com.tibco.bw.palette.writetolog.model.writetolog;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see com.tibco.bw.palette.writetolog.model.writetolog.WritetologFactory
 * @model kind="package"
 * @generated
 */
public interface WritetologPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "writetolog";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://ns.tibco.com/bw/palette/writetolog";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "writetolog";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	WritetologPackage eINSTANCE = com.tibco.bw.palette.writetolog.model.writetolog.impl.WritetologPackageImpl.init();

	/**
	 * The meta object id for the '{@link com.tibco.bw.palette.writetolog.model.writetolog.impl.LogImpl <em>Log</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.tibco.bw.palette.writetolog.model.writetolog.impl.LogImpl
	 * @see com.tibco.bw.palette.writetolog.model.writetolog.impl.WritetologPackageImpl#getLog()
	 * @generated
	 */
	int LOG = 0;

	/**
	 * The feature id for the '<em><b>Write To Log</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOG__WRITE_TO_LOG = 0;

	/**
	 * The number of structural features of the '<em>Log</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOG_FEATURE_COUNT = 1;


	/**
	 * Returns the meta object for class '{@link com.tibco.bw.palette.writetolog.model.writetolog.Log <em>Log</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Log</em>'.
	 * @see com.tibco.bw.palette.writetolog.model.writetolog.Log
	 * @generated
	 */
	EClass getLog();

	/**
	 * Returns the meta object for the attribute '{@link com.tibco.bw.palette.writetolog.model.writetolog.Log#getWriteToLog <em>Write To Log</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Write To Log</em>'.
	 * @see com.tibco.bw.palette.writetolog.model.writetolog.Log#getWriteToLog()
	 * @see #getLog()
	 * @generated
	 */
	EAttribute getLog_WriteToLog();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	WritetologFactory getWritetologFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link com.tibco.bw.palette.writetolog.model.writetolog.impl.LogImpl <em>Log</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.tibco.bw.palette.writetolog.model.writetolog.impl.LogImpl
		 * @see com.tibco.bw.palette.writetolog.model.writetolog.impl.WritetologPackageImpl#getLog()
		 * @generated
		 */
		EClass LOG = eINSTANCE.getLog();

		/**
		 * The meta object literal for the '<em><b>Write To Log</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOG__WRITE_TO_LOG = eINSTANCE.getLog_WriteToLog();

	}

} //WritetologPackage
