package com.tibco.bw.palette.writetolog.model.utils;

public interface MessageCode {
	public static final String PARAMETER_NOT_SPECIFIED= "BW-WRITETOLOG-100001";
}
