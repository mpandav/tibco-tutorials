package com.tibco.bw.palette.writetolog.model.writetolog;

import com.tibco.bw.palette.writetolog.model.writetolog.Log;
import com.tibco.bw.validation.process.ActivityConfigurationValidator;
import com.tibco.bw.validation.process.ActivityValidationContext;
import com.tibco.bw.palette.writetolog.model.writetolog.WritetologPackage;
import com.tibco.bw.palette.writetolog.model.utils.Messages;
import com.tibco.bw.palette.writetolog.model.utils.MessageCode;
import org.eclipse.osgi.util.NLS;

// begin-custom-code
// add your own business code here
// end-custom-code

public class LogValidator implements ActivityConfigurationValidator {	

	// begin-custom-code
	// add your own business code here
	// end-custom-code

	/**
	 * <!-- begin-custom-doc -->
	 * 
	 * <!-- end-custom-doc -->
	 * @generated
	 * Validates Activity model configuration.
	 * @param context
	 *			The activity validation context.Developers can retrieve following informations:
	 *          <li> Activity Configuration Model(EMF model)</li>
 	 *          <li> Name of the EventSource Activity</li>
     *          <li> Value of process property used in Activity Configuration</li>
     *          <li> Name of property configured in the Attribute Binding Field</li>
     *          <li> Name of the process</li><br>
	 */	
	@Override
	public void validateBWActivityConfiguration(ActivityValidationContext context) {
	    Log model = (Log) context.getActivityConfigurationModel();    	
		
	    String WriteToLogModul = context.getAttributeBindingPropertyName("WriteToLog");
		if(WriteToLogModul == null || "".equals(WriteToLogModul)){
		    String WriteToLog = model.getWriteToLog(); 
		    if(WriteToLog == null || "".equals(WriteToLog)) {
		        String message = ""; //$NON-NLS-1$
		        message = NLS.bind(Messages.PALETTE_PARAMETER_VALUE_INVALID, new String[] {"Label"});
		        context.createError(message, null, MessageCode.PARAMETER_NOT_SPECIFIED, WritetologPackage.Literals.LOG__WRITE_TO_LOG);
		    }
		}	
		// begin-custom-code
		// add your own business code here
		// end-custom-code
  	}
}
