package com.tibco.bw.palette.writetolog.design.log;

import org.eclipse.emf.ecore.EObject;
import com.tibco.bw.design.api.BWAbstractModelHelper;
import com.tibco.bw.palette.writetolog.model.writetolog.WritetologFactory;
import com.tibco.bw.palette.writetolog.model.writetolog.Log;

// begin-custom-code
// add your own business code here
// end-custom-code

public class LogModelHelper extends BWAbstractModelHelper {

	/**
	 * <!-- begin-custom-doc -->
	 * 
	 * <!-- end-custom-doc -->
	 * @generated
	 *
	 * Create an instance of the activity configuration model and provide "good" default values.
	 *
	 * @return new instance
	 */
    @Override
    public EObject createInstance() {
        Log activity = WritetologFactory.eINSTANCE.createLog();
    		// begin-custom-code
    		// add your own business code here
    		// end-custom-code
        return activity;
    }
}
