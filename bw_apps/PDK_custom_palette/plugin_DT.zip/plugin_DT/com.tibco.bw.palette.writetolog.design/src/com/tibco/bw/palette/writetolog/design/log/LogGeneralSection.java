package com.tibco.bw.palette.writetolog.design.log;

import com.tibco.bw.palette.writetolog.model.writetolog.WritetologPackage;
import org.eclipse.swt.widgets.Text;

import org.eclipse.swt.widgets.Composite;
import com.tibco.bw.design.field.BWFieldFactory;
import com.tibco.bw.design.propertysection.AbstractBWTransactionalSection;
import com.tibco.bw.palette.writetolog.model.writetolog.Log;
import com.tibco.bw.palette.writetolog.model.utils.Messages;

// begin-custom-code
// add your own business code here
// end-custom-code

/**
 * General tab properties for the activity.
 */
public class LogGeneralSection extends AbstractBWTransactionalSection {

	// begin-custom-code
	// add your own business code here
	// end-custom-code

    /**
     * <!-- begin-custom-doc -->
     * 
     * <!-- end-custom-doc -->
     * @generated
     */
    private Text writeToLog;
    


    @Override
    protected Class<?> getModelClass() {
       return Log.class;
    }

    /**
	 * <!-- begin-custom-doc -->
     * 
	 * <!-- end-custom-doc -->
	 * @generated
	 *
	 * Initialize bindings of controls to the input. 
	 */
    @Override
    protected void initBindings() {
        getBindingManager().bind(writeToLog, getInput(), WritetologPackage.Literals.LOG__WRITE_TO_LOG); 
    
        // begin-custom-code
        // add your own business code here
        // end-custom-code
    }

	/**
	 * <!-- begin-custom-doc -->
	 * 
	 * <!-- end-custom-doc -->
	 * @generated
	 *
	 * This method creates section-specific UI.
	 * @param root
	 * @return
	 */
    @Override
    protected Composite doCreateControl(final Composite root) {
        Composite parent = BWFieldFactory.getInstance().createComposite(root, 2);
   	    BWFieldFactory.getInstance().createLabel(parent, Messages.LOG_WRITETOLOG, true);
   	    writeToLog = BWFieldFactory.getInstance().createTextBox(parent);
   	    writeToLog.setToolTipText(Messages.LOG_WRITETOLOG_TOOLTIP);

		// begin-custom-code
		// add your own business code here
		// end-custom-code
        return parent;
    }
}
