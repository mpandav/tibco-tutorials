package com.tibco.bw.palette.writetolog.runtime;

import java.io.Serializable;
import java.io.IOException;
import com.tibco.bw.runtime.AsyncActivity;
import com.tibco.bw.runtime.AsyncActivityCompletionNotifier;
import com.tibco.bw.runtime.ProcessContext;
import com.tibco.bw.runtime.annotation.Property;
import com.tibco.bw.runtime.util.SerializableXMLDocument;
import com.tibco.bw.runtime.ActivityLifecycleFault;
import com.tibco.bw.runtime.AsyncActivityController;
import com.tibco.bw.runtime.ActivityFault;
import com.tibco.bw.runtime.util.XMLUtils;
import com.tibco.neo.localized.LocalizedMessage;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.genxdm.ProcessingContext;
import org.genxdm.Model;

import com.tibco.bw.palette.writetolog.model.writetolog.Log;

// begin-custom-code
// add your own business code here
// end-custom-code

public class LogAsynchronousActivity<N> extends AsyncActivity<N> implements WriteToLogConstants {

	// begin-custom-code
	// add your own business code here
	// end-custom-code

	private ExecutorService threadPool = null;
	private final ConcurrentHashMap<String, LogActivityExecutor> executingTasks = new ConcurrentHashMap<>();
	
	@Property
	public Log activityConfig;


    /**
	 * <!-- begin-custom-doc -->
	 * 
	 * <!-- end-custom-doc -->
	 * @generated
	 *
	 * This method is called to initialize the activity. It is called by the 
	 * BusinessWorks Engine once for a particular activity lifetime.
	 * 
	 * @throws ActivityLifecycleFault
	 *             Thrown if the activity initialization is unsuccessful or encounters an error.
	 */
    @Override
	public void init() throws ActivityLifecycleFault {
		if(this.getActivityLogger().isDebugEnabled()) {
			activityLogger.debug(RuntimeMessageBundle.DEBUG_PLUGIN_ACTIVITY_METHOD_CALLED
								,new Object[] { "init()"
								,activityContext.getActivityName()
								,activityContext.getProcessName()
								,activityContext.getDeploymentUnitName()
								,activityContext.getDeploymentUnitVersion() });
		}


		// begin-custom-code
        // add your own business code here
        // end-custom-code
		super.init();
		threadPool = Executors.newCachedThreadPool();
	}
	
	/**
  	 * <!-- begin-custom-doc -->
  	 * 
  	 * <!-- end-custom-doc -->
  	 * @generated
  	 *
	 * This method is called when an activity is destroyed. It is called by the BusinessWorks Engine and 
	 * the method must be implemented to release or clean up any resources held by this activity.
  	 */
    @Override
  	public void destroy() {
  		if(this.getActivityLogger().isDebugEnabled()) {
			activityLogger.debug(RuntimeMessageBundle.DEBUG_PLUGIN_ACTIVITY_METHOD_CALLED
								,new Object[] { "destroy()"
								,activityContext.getActivityName()
								,activityContext.getProcessName()
								,activityContext.getDeploymentUnitName()
								,activityContext.getDeploymentUnitVersion() });
		}
		// begin-custom-code
		// add your own business code here
		// end-custom-code
		super.destroy();
  	}
  	
	/**
	 * <!-- begin-custom-doc -->
	 * 
	 * <!-- end-custom-doc -->
	 * @generated
	 *
	 * Cancels the execution of the asynchronous activity implementation. This method is called by BusinessWorks 
	 * Engine when the asynchronous activity has not completed within the wait time specified in the call to the 
	 * method {@link AsyncActivityController#setPending} or when the BusinessWorks Engine or the application is shutting down.
	 * <p>
	 * If this method is called by BusinessWorks Engine, then the asynchronous activity method {@link AsyncActivity#postExecute} will not be called.
	 *  
	 * @param processContext
	 *           Context that is associated with a BusinessWorks Process instance. This context is unique per BusinessWorks Process instance and it 
	 *           is not visible to other BusinessWorks Process instances.  Also this context is valid only within the BusinessWorks Engine thread on 
	 *           which this method is invoked. Therefore this context must not be saved or used by a different thread that is created or managed by the activity
	 *           implementation. 
	 */
	@Override
	public void cancel(ProcessContext<N> processContext) {
		if(this.getActivityLogger().isDebugEnabled()) {
			activityLogger.debug(RuntimeMessageBundle.DEBUG_PLUGIN_ACTIVITY_METHOD_CALLED
								,new Object[] { "cancel()"
								,activityContext.getActivityName()
								,activityContext.getProcessName()
								,activityContext.getDeploymentUnitName()
								,activityContext.getDeploymentUnitVersion() });
		}
    	String taskId = processContext.getActivityExecutionId() + activityContext.getActivityName();
		LogActivityExecutor executor = executingTasks.remove(taskId);
		
    	// begin-custom-code
        // add your own business code here
        // end-custom-code
		
    	if(executor!=null) {
    		executor.requestCancel();
    	}
	}

	/**
	 * <!-- begin-custom-doc -->
	 * 
	 * <!-- end-custom-doc -->
	 * @generated
	 *
	 * Starts the execution of the asynchronous activity implementation.  This method is called by the BusinessWorks Engine 
	 * on a engine thread; however the activity logic must be executed on an independent thread. 
	 * 
	 * @param input
	 *           This is the activity input data. It is an XML Element which adheres to the input schema of the activity or <code>null</code> if the activity does not require an input.
	 *           The activity input data should be processed using the XML processing context obtained from the method {@link ProcessContext#getXMLProcessingContext()}.
	 * @param processContext
	 *           Context that is associated with a BusinessWorks Process instance. This context is unique per BusinessWorks Process instance and it 
	 *           is not visible to other BusinessWorks Process instances.  Also this context is valid only within the BusinessWorks Engine thread on 
	 *           which this method is invoked. Therefore this context must <b>not</b> be saved or used by a different thread that is created or managed by the activity
	 *           implementation. 
	 * @param activityController
	 *           Controller used to set the asynchronous activity wait time and to obtain the asynchronous activity completion notifier {@link AsyncActivityCompletionNotifier}. 
	 			 This controller is only valid within this method invocation and must <b>not</b> be saved or held by this method implementation.
	 * @throws ActivityFault
	 */
	@Override
	public void execute(N input, ProcessContext<N> processContext, AsyncActivityController asyncActivityController) throws ActivityFault {
		if(this.getActivityLogger().isDebugEnabled()) {
			activityLogger.debug(RuntimeMessageBundle.DEBUG_PLUGIN_ACTIVITY_METHOD_CALLED
								,new Object[] { "execute()"
								,activityContext.getActivityName()
								,activityContext.getProcessName()
								,activityContext.getDeploymentUnitName()
								,activityContext.getDeploymentUnitVersion() });
		}
		AsyncActivityCompletionNotifier notifier = asyncActivityController.setPending(0);
		
		// begin-custom-code
        // add your own business code here
        // end-custom-code
		System.out.println("########### ACTIVITY INPUT DATA  ##########");
       
		
        String logMessage = "";
        String msgCode = "";
        String loggerName = "";
        String errorCode = "";
        String severity = "";
        String logLevel = "";
        
        // retrieving message element from input
        ProcessingContext<N> pcx = (org.genxdm.ProcessingContext<N>)processContext.getXMLProcessingContext();
        final Model<N> model = (Model<N>)pcx.getModel();
        if (input != null) {
            final N messageNode = (N)model.getFirstChildElementByName((N)input, (String)null, "message");
            if (messageNode != null) {
                logMessage = model.getStringValue((N)messageNode);
            }
        }
		
        // retrieving msgCode element from input
        if (input != null) {
            final N msgCodeNode = (N)model.getFirstChildElementByName((N)input, (String)null, "msgCode");
            if (msgCodeNode != null) {
            	msgCode = model.getStringValue((N)msgCodeNode);
            }
        }
        
        // retrieving loggerName element from input
        if (input != null) {
            final N loggerNameNode = (N)model.getFirstChildElementByName((N)input, (String)null, "loggerName");
            if (loggerNameNode != null) {
            	loggerName = model.getStringValue((N)loggerNameNode);
            }
        }
        
        // retrieving errorCode element from input
        if (input != null) {
            final N errorCodeNode = (N)model.getFirstChildElementByName((N)input, (String)null, "errorCode");
            if (errorCodeNode != null) {
            	errorCode = model.getStringValue((N)errorCodeNode);
            }
        }
        
        // retrieving severity element from input
        if (input != null) {
            final N severityNode = (N)model.getFirstChildElementByName((N)input, (String)null, "severity");
            if (severityNode != null) {
            	severity = model.getStringValue((N)severityNode);
            }
        }
        
        // retrieving logLevel element from input

        if (input != null) {
            final N logLevelNode = (N)model.getFirstChildElementByName((N)input, (String)null, "logLevel");
            if (logLevelNode != null) {
            	logLevel = model.getStringValue((N)logLevelNode);
            }
        }
        
		LogActivityExecutor executor = new LogActivityExecutor(notifier, input, processContext);
		threadPool.submit(executor);
		String taskId = processContext.getActivityExecutionId() + this.getActivityContext().getActivityName();
		executingTasks.put(taskId, executor);
		
		
		
		// Printing each Input element on console
		System.out.println("msgCode : " + msgCode);
		System.out.println("loggerName :" + loggerName);
		System.out.println("logLevel : " + logLevel);
		System.out.println("message : " + logMessage);
		System.out.println("errorCode : " + errorCode);
		System.out.println("severity : " + severity);
	}
	
	/**
	 * <!-- begin-custom-doc -->
	 * 
	 * <!-- end-custom-doc -->
	 * @generated
	 *
	 * Completes the execution of the asynchronous activity implementation. This method is called by the BusinessWorks 
	 * Engine after the asynchronous activity has signaled ready for completion by invoking the 
	 * method {@link AsyncActivityCompletionNotifier#setReady} from the activity's independent thread.
	 * <p>
	 * Before processing the argument <code>activityData</code> of this method, the type must be checked. If the type is {@link com.tibco.bw.runtime.util.SerializableXMLDocument}
	 * then the enclosed XML document can be extracted for further processing. 
	 * <p>
	 * 
	 * @param value 
	 *           Activity data that is passed to the method {@link AsyncActivityCompletionNotifier#setReady} by the asynchronous activity.
	 * @param processContext
	 *           Context that is associated with a BusinessWorks Process instance. This context is unique per BusinessWorks Process instance and it 
	 *           is not visible to other BusinessWorks Process instances.  Also this context is valid only within the BusinessWorks Engine thread on 
	 *           which this method is invoked. Therefore this context must not be saved or used by a different thread that is created or managed by the activity
	 *           implementation. 
	 * @return An XML Element which adheres to the output schema of the activity or may return <code>null</code> if the activity does not require an output. 
     *         This is the activity output data and it should be created using the XML processing context obtained from the method {@link ProcessContext#getXMLProcessingContext()}.
	 * @throws ActivityFault
	 */
	@SuppressWarnings("unchecked")
	@Override
	public N postExecute(Serializable value, ProcessContext<N> processContext) throws ActivityFault {
		if(this.getActivityLogger().isDebugEnabled()) {
			activityLogger.debug(RuntimeMessageBundle.DEBUG_PLUGIN_ACTIVITY_METHOD_CALLED
								,new Object[] { "postExecute()"
								,activityContext.getActivityName()
								,activityContext.getProcessName()
								,activityContext.getDeploymentUnitName()
								,activityContext.getDeploymentUnitVersion() });
		}
		if (value instanceof ActivityFault) {
			throw (ActivityFault)value;
		} else {
			try {
			 	// begin-custom-code
		        // add your own business code here
		        // end-custom-code

				
				
				N output = ((SerializableXMLDocument<N>)value).getXMLDocument(processContext.getXMLProcessingContext());
				return output;
			} catch (IOException e) {
				throw new ActivityFault(activityContext, new LocalizedMessage(
						RuntimeMessageBundle.ERROR_OCCURED_RETRIEVE_RESULT, new Object[] {activityContext.getActivityName()}));
			}
		}
	}
	
	class LogActivityExecutor implements Runnable {
		private final AsyncActivityCompletionNotifier notifier;
		private final N inputData;
		private final ProcessContext<N> processContext;
		
		/**
		 * Use this variable to determine if a cancel was requested.
		 * Typically used as a loop condition in run() so it can end 
		 * when cancelRequested becomes true.
		 */ 
		@SuppressWarnings("unused")
		private boolean cancelRequested = false;
		
		public void requestCancel() {
			this.cancelRequested = true;
		}
		
		public LogActivityExecutor(AsyncActivityCompletionNotifier notifier, N input, ProcessContext<N> processContext) {
			this.notifier = notifier;
			this.inputData = input;
			this.processContext = processContext;
		}

		/**
		 * <!-- begin-custom-doc -->
		 * 
		 * <!-- end-custom-doc -->
		 * @generated
		 */
		@Override
		public void run() {
			if(getActivityLogger().isDebugEnabled()) {
				activityLogger.debug(RuntimeMessageBundle.DEBUG_PLUGIN_ACTIVITY_METHOD_CALLED
									,new Object[] { "Executor run()"
									,activityContext.getActivityName()
									,activityContext.getProcessName()
									,activityContext.getDeploymentUnitName()
									,activityContext.getDeploymentUnitVersion() });
				String serializedNode = XMLUtils.serializeNode(inputData, processContext.getXMLProcessingContext());
		    	activityLogger.debug(RuntimeMessageBundle.DEBUG_PLUGIN_ACTIVITY_INPUT, new Object[] {activityContext.getActivityName(), serializedNode});
			}
			
			try {				
				// begin-custom-code
				// add your own business code here
				// end-custom-code
				
				N output = null;
				SerializableXMLDocument<N> wrapper = new SerializableXMLDocument<N>(processContext.getXMLProcessingContext(), output);
				notifier.setReady(wrapper);
			} catch (Exception e) {
				e.printStackTrace();
				notifier.setReady(e);
			}
		}
	}
}
