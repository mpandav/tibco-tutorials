package com.tibco.bw.palette.writetolog.runtime.fault;

import com.tibco.bw.runtime.ActivityLifecycleFault;

public class WriteToLogActivityLifecycleFault extends ActivityLifecycleFault {
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 6098514979064369160L;


	public WriteToLogActivityLifecycleFault(String message) {
		super(message);
	}
}
